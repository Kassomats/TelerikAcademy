﻿namespace Agency.Commands.Creating
{
    // TODO
    class ListVehiclesCommand
    {
        
    }
}
